import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Navbar.css';

function Navbar({ activePage }) {
  return (
    <header className="navbar">
      <h1 className="navbar-title">EV Battery Digital Twin Platform</h1>
      <nav className="nav-links">
        <Link className={`nav-link ${activePage === 'Dashboard' ? 'active' : ''}`} to="/">Dashboard</Link>
        <Link className={`nav-link ${activePage === 'Simulation' ? 'active' : ''}`} to="/simulation">Simulation</Link>
        <Link className={`nav-link ${activePage === 'Optimization' ? 'active' : ''}`} to="/optimization">Optimization</Link>
        <Link className={`nav-link ${activePage === 'WhatIfAnalysis' ? 'active' : ''}`} to="/whatifanalysis">What-If Analysis</Link>
      
      </nav>
    </header>
  );
}

export default Navbar;

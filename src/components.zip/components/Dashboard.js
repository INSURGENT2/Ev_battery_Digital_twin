import React, { useEffect, useState } from 'react';
import Navbar from './Navbar';
import '../styles/Dashboard.css';

function Dashboard() {
  const [predictiveData, setPredictiveData] = useState(null);
  const [notification, setNotification] = useState(null);

  useEffect(() => {
    const fetchPredictiveData = async () => {
      try {
        const response = await fetch('http://127.0.0.1:5000/predictive-data'); // Ensure the endpoint matches your Flask server
        const data = await response.json();
        setPredictiveData(data);

        // Check if high risk and show notification
        if (data.high_risk && data.high_risk[0]) {
          setNotification('High Risk Detected! Immediate Attention Required.');
        } else {
          setNotification(null);
        }
      } catch (error) {
        console.error('Error fetching predictive data:', error);
      }
    };

    // Fetch data immediately and set up interval
    fetchPredictiveData();
    const interval = setInterval(fetchPredictiveData, 10000); // Fetch every 10 seconds

    // Cleanup interval on unmount
    return () => clearInterval(interval);
  }, []);

  const closeNotification = () => {
    setNotification(null);
  };

  return (
    <div className="dashboard">
      <Navbar activePage="Dashboard" />
      <main className="main-content">
        <div className="visualization-placeholder">
          <h2>3D Battery Module Digital Twin</h2>
          <svg viewBox="0 0 500 500">
            <polygon points="150,300 250,200 350,300 250,400" fill="#4ECDC4" opacity="0.7" />
            <polygon points="180,330 250,230 320,330 250,430" fill="#2D3748" opacity="0.5" />
          </svg>
        </div>
        <div className="metrics">
          <h2>Cell Preparation Metrics</h2>
          {predictiveData ? (
            <>
              <div className="metric">Inspection Pass Rate: <span className="highlight-green">{predictiveData.input_data.inspection_pass_rate}</span></div>
              <div className="metric">Temperature: <span className="highlight-blue">{predictiveData.input_data.temperature}</span></div>
              <div className="metric">Vibration Level: <span className="highlight-red">{predictiveData.input_data.vibration_level}</span></div>
              <div className="metric">Energy Consumption: <span className="highlight-pink">{predictiveData.input_data.energy_consumption}</span></div>
              <div className="metric">Failure Probability: <span className="highlight-red">{predictiveData.failure_probability[0].toFixed(2)}</span></div>
              <div className="metric">Time-to-Failure: <span className="highlight-blue">{predictiveData.time_to_failure[0].toFixed(2)} minutes</span></div>
              <div className="metric">High Risk: <span className={predictiveData.high_risk[0] ? 'highlight-red' : 'highlight-green'}>{predictiveData.high_risk[0] ? 'Yes' : 'No'}</span></div>
            </>
          ) : (
            <p>Loading predictive data...</p>
          )}
        </div>

        {notification && (
          <div className="toast-notification">
            <p>{notification}</p>
            <button className="close-btn" onClick={closeNotification}>
              Close
            </button>
          </div>
        )}
      </main>
    </div>
  );
}

export default Dashboard;

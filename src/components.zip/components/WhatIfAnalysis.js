import React, { useState } from 'react';
import Navbar from './Navbar';
import '../styles/WhatIfAnalysis.css';

function WhatIfAnalysis() {
  const [inputData, setInputData] = useState({
    inspection_pass_rate: 90,
    temperature: 80,
    vibration_level: 0.5,
    energy_consumption: 55,
    ambient_temperature: 25,
    humidity: 50,
    air_quality_index: 40,
    completion_time: 50,
    process_yield: 95,
    cycle_time: 180,
    resource_utilization_rate: 85,
    order_completion_time: 7,
    inspection_time: 12,
    defect_rate: 3,
    downtime_logged: 30,
  });

  const [analysisResult, setAnalysisResult] = useState(null);

  const handleChange = (event, key) => {
    const value = event.target.value;
    setInputData({ ...inputData, [key]: parseFloat(value) });
  };

  const handleRunAnalysis = async () => {
    try {
      const response = await fetch('http://127.0.0.1:5000/predictive-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(inputData),
      });
      const result = await response.json();
      setAnalysisResult(result);
    } catch (error) {
      console.error('Error running analysis:', error);
    }
  };

  const resetAnalysis = () => {
    setAnalysisResult(null);
  };

  return (
    <div className="whatifanalysis">
      <Navbar activePage="WhatIfAnalysis" />
      <main className="main-content">
        {!analysisResult ? (
          <div className="sliders-page">
            <h2>What-If Analysis</h2>
            <div className="sliders-grid">
              {Object.keys(inputData).map((key) => (
                <div key={key} className="slider-item">
                  <label>
                    {key.replace(/_/g, ' ').toUpperCase()}: <span>{inputData[key]}</span>
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="1"
                    value={inputData[key]}
                    onChange={(e) => handleChange(e, key)}
                  />
                </div>
              ))}
            </div>
            <button className="action-button" onClick={handleRunAnalysis}>
              Run Analysis
            </button>
          </div>
        ) : (
          <div className="results-page">
            <h2>Analysis Results</h2>
            <ul>
              <li>Failure Probability: {analysisResult.failure_probability[0].toFixed(2)}</li>
              <li>Time-to-Failure: {analysisResult.time_to_failure[0].toFixed(2)} minutes</li>
              <li>
                High Risk:{' '}
                <span className={analysisResult.high_risk[0] ? 'highlight-red' : 'highlight-green'}>
                  {analysisResult.high_risk[0] ? 'Yes' : 'No'}
                </span>
              </li>
              <li>Notification: {analysisResult.notification}</li>
            </ul>
            <button className="action-button" onClick={resetAnalysis}>
              Try Another Input
            </button>
          </div>
        )}
      </main>
    </div>
  );
}

export default WhatIfAnalysis;

import React, { useEffect } from 'react';
import Navbar from './Navbar';
import '../styles/Simulation.css';

function Simulation() {
  useEffect(() => {
    const randomValue = (min, max) => (Math.random() * (max - min) + min).toFixed(2);

    const updateSimulationMetrics = () => {
      // Safely query elements and update only if they exist
      const temperatureEl = document.querySelector('.highlight-green-temperature');
      const speedEl = document.querySelector('.highlight-green-speed');
      const energyEl = document.querySelector('.highlight-green-energy');

      const throughputBar = document.querySelector('.progress-throughput');
      const defectBar = document.querySelector('.progress-defect');
      const energyBar = document.querySelector('.progress-energy');

      const throughputValue = document.querySelector('.throughput-value');
      const defectRateValue = document.querySelector('.defect-rate-value');
      const energyConsumptionValue = document.querySelector('.energy-consumption-value');

      if (temperatureEl) temperatureEl.textContent = `${randomValue(470, 510)}°C`;
      if (speedEl) speedEl.textContent = `${randomValue(120, 150)} mm/s`;
      if (energyEl) energyEl.textContent = `${randomValue(85, 100)} kWh`;

      if (throughputBar) throughputBar.style.width = `${randomValue(60, 100)}%`;
      if (defectBar) defectBar.style.width = `${randomValue(5, 15)}%`;
      if (energyBar) energyBar.style.width = `${randomValue(50, 90)}%`;

      if (throughputValue) throughputValue.textContent = `${randomValue(170, 200)} units/h`;
      if (defectRateValue) defectRateValue.textContent = `${randomValue(1, 2.5)}%`;
      if (energyConsumptionValue) energyConsumptionValue.textContent = `${randomValue(90, 100)} kWh`;
    };

    updateSimulationMetrics(); // Run once on mount
    const interval = setInterval(updateSimulationMetrics, 6000); // Update every 6 seconds

    return () => clearInterval(interval); // Cleanup interval on unmount
  }, []);

  return (
    <div className="simulation">
      <Navbar activePage="Simulation" />
      <main className="main-content">
        <div className="input-parameters">
          <h2>Input Parameters</h2>
          <ul>
            <li>Welding Temperature: <span className="highlight-green-temperature">490°C</span></li>
            <li>Stacking Speed: <span className="highlight-green-speed">135 mm/s</span></li>
            <li>Energy Consumption Limit: <span className="highlight-green-energy">95 kWh</span></li>
          </ul>
        </div>
        <div className="simulation-results">
          <h2>Simulation Results</h2>
          <div className="result-bar">
            <span>Throughput</span>
            <div className="progress-bar">
              <div className="progress progress-throughput"></div>
            </div>
            <span className="throughput-value">180 units/h</span>
          </div>
          <div className="result-bar">
            <span>Defect Rate</span>
            <div className="progress-bar">
              <div className="progress progress-defect"></div>
            </div>
            <span className="defect-rate-value">1.5%</span>
          </div>
          <div className="result-bar">
            <span>Energy Consumption</span>
            <div className="progress-bar">
              <div className="progress progress-energy"></div>
            </div>
            <span className="energy-consumption-value">95 kWh</span>
          </div>
        </div>
        <div className="recommendations">
          <h2>Recommendations</h2>
          <ul>
            <li>Increase stacking speed to 135 mm/s</li>
            <li>Decrease welding temperature to 480°C</li>
            <li>Optimize energy consumption to 95 kWh</li>
          </ul>
        </div>
      </main>
    </div>
  );
}

export default Simulation;

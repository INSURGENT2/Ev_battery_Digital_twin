import React, { useEffect, useState } from 'react';
import Navbar from './Navbar';
import '../styles/Optimization.css';

function Optimization() {
  const [optimizationMetrics, setOptimizationMetrics] = useState(null);

  useEffect(() => {
    const fetchOptimizationMetrics = async () => {
      try {
        const response = await fetch('http://127.0.0.1:5000/optimization-data');
        const data = await response.json();
        setOptimizationMetrics(data);
      } catch (error) {
        console.error('Error fetching optimization metrics:', error);
      }
    };

    fetchOptimizationMetrics();
    const interval = setInterval(fetchOptimizationMetrics, 6000);

    return () => clearInterval(interval);
  }, []);

  if (!optimizationMetrics) {
    return (
      <div className="optimization">
        <Navbar activePage="Optimization" />
        <main className="main-content">
          <p>Loading optimization data...</p>
        </main>
      </div>
    );
  }

  return (
    <div className="optimization">
      <Navbar activePage="Optimization" />
      <main className="main-content">
        <div className="current-settings">
          <h2>Current Process Settings</h2>
          <ul>
            <li>
              Welding Temperature:{' '}
              <span className="highlight-green-temperature">
                {optimizationMetrics.current_settings.welding_temperature}
              </span>
            </li>
            <li>
              Stacking Speed:{' '}
              <span className="highlight-green-speed">
                {optimizationMetrics.current_settings.stacking_speed}
              </span>
            </li>
            <li>
              Energy Consumption:{' '}
              <span className="highlight-green-energy">
                {optimizationMetrics.current_settings.energy_consumption}
              </span>
            </li>
            <li>
              Thermal Uniformity:{' '}
              <span className="highlight-green-uniformity">
                {optimizationMetrics.current_settings.thermal_uniformity}
              </span>
            </li>
          </ul>
        </div>
        <div className="goals">
          <h2>Optimization Goals</h2>
          <ul>
            <li>
              Maximize Throughput:{' '}
              <span className="highlight-goal-throughput">
                {optimizationMetrics.optimization_goals.throughput}
              </span>
            </li>
            <li>
              Minimize Defect Rate:{' '}
              <span className="highlight-goal-defect">
                {optimizationMetrics.optimization_goals.defect_rate}
              </span>
            </li>
            <li>
              Reduce Energy Consumption:{' '}
              <span className="highlight-goal-energy">
                {optimizationMetrics.optimization_goals.energy_consumption}
              </span>
            </li>
          </ul>
        </div>
        <div className="recommendations">
          <h2>Recommended Adjustments</h2>
          <ul>
            {optimizationMetrics.recommended_adjustments.map((adjustment, index) => (
              <li key={index}>{adjustment}</li>
            ))}
          </ul>
        </div>
        {optimizationMetrics.notification && (
          <div className="notification">
            <p>{optimizationMetrics.notification}</p>
          </div>
        )}
      </main>
    </div>
  );
}

export default Optimization;
